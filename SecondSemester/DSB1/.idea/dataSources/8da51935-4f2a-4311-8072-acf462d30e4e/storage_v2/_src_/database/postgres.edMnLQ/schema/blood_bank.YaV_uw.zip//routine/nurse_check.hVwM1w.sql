create function nurse_check() returns trigger
    language plpgsql
as
$$
BEGIN
    IF 'nurse' != (SELECT position FROM staff WHERE initials = new.verified_by_nurse_initials) OR
       'nurse' != (SELECT position FROM staff WHERE initials = new.collected_by_nurse_initials) THEN
        RAISE EXCEPTION 'Inserted staff is not Nurse';
    END IF;
    RETURN new;
END;
$$;

alter function nurse_check() owner to postgres;

