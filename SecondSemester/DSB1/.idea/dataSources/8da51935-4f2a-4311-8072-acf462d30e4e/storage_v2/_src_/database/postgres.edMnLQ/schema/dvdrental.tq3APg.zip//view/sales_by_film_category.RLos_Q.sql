create view sales_by_film_category(category, total_sales) as
SELECT c.name        AS category,
       sum(p.amount) AS total_sales
FROM dvdrental.payment p
         JOIN dvdrental.rental r ON p.rental_id = r.rental_id
         JOIN dvdrental.inventory i ON r.inventory_id = i.inventory_id
         JOIN dvdrental.film f ON i.film_id = f.film_id
         JOIN dvdrental.film_category fc ON f.film_id = fc.film_id
         JOIN dvdrental.category c ON fc.category_id = c.category_id
GROUP BY c.name
ORDER BY (sum(p.amount)) DESC;

alter table sales_by_film_category
    owner to postgres;

