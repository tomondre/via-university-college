create view sales_by_store(store, manager, total_sales) as
SELECT (c.city::text || ','::text) || cy.country::text        AS store,
       (m.first_name::text || ' '::text) || m.last_name::text AS manager,
       sum(p.amount)                                          AS total_sales
FROM dvdrental.payment p
         JOIN dvdrental.rental r ON p.rental_id = r.rental_id
         JOIN dvdrental.inventory i ON r.inventory_id = i.inventory_id
         JOIN dvdrental.store s ON i.store_id = s.store_id
         JOIN dvdrental.address a ON s.address_id = a.address_id
         JOIN dvdrental.city c ON a.city_id = c.city_id
         JOIN dvdrental.country cy ON c.country_id = cy.country_id
         JOIN dvdrental.staff m ON s.manager_staff_id = m.staff_id
GROUP BY cy.country, c.city, s.store_id, m.first_name, m.last_name
ORDER BY cy.country, c.city;

alter table sales_by_store
    owner to postgres;

