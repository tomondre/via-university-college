create function guestid_update_in_booking() returns trigger
    language plpgsql
as
$$
begin
    if new.guestno is distinct from old.guestno then
        update booking set guestno = new.guestno where guestno = old.guestno;
    end if;
    return new;
end;
$$;

alter function guestid_update_in_booking() owner to postgres;

