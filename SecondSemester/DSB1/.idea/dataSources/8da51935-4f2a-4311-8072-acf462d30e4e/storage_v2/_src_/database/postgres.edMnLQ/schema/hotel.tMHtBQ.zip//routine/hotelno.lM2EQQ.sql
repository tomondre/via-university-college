create function hotelno() returns trigger
    language plpgsql
as
$$
begin
    if new.hotelno is distinct from old.hotelno then
        raise exception 'Exception - forbidden updating hotelno of a room';
    end if;
    return new;
end;
$$;

alter function hotelno() owner to postgres;

