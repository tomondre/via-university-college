create function name_uppercase() returns trigger
    language plpgsql
as
$$
begin
    new.hotelname = upper(new.hotelname);
    return new;
end;
$$;

alter function name_uppercase() owner to postgres;

