create function version_update() returns trigger
    language plpgsql
as
$$
begin
    if new.price is distinct from old.price then
--         update room set version = old.version where roomno = old.roomno;
        new.version = old.version + 1;
        end if;
    return new;
end;
$$;

alter function version_update() owner to postgres;

