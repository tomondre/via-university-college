create view ex1_1(guestname, roomno) as
SELECT guest.guestname,
       b.roomno
FROM hotel.guest
         JOIN hotel.booking b ON b.guestno = guest.guestno
         LEFT JOIN hotel.room r ON b.roomno = r.roomno;

alter table ex1_1
    owner to postgres;

