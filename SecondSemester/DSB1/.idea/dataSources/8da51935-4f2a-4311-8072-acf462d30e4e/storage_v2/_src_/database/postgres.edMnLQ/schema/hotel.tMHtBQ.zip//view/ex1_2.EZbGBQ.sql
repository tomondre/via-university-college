create view ex1_2(booking, type) as
SELECT booking.*::hotel.booking AS booking,
       room.type
FROM hotel.booking
         JOIN hotel.room ON booking.roomno = room.roomno
WHERE room.type::text = 'Single'::text;

alter table ex1_2
    owner to postgres;

