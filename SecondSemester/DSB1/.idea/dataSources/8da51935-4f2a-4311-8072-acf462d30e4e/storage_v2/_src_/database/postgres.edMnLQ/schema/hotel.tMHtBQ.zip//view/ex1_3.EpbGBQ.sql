create view ex1_3(hotelno, guestno, datefrom, dateto, roomno) as
SELECT booking.hotelno,
       booking.guestno,
       booking.datefrom,
       booking.dateto,
       booking.roomno
FROM hotel.booking
WHERE booking.dateto IS NULL;

alter table ex1_3
    owner to postgres;

