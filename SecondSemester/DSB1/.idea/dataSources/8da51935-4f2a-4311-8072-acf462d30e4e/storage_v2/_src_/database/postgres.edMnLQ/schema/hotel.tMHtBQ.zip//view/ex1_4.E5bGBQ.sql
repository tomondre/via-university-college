create view ex1_4(room, hotelname) as
SELECT room.*::hotel.room AS room,
       h.hotelname
FROM hotel.room
         JOIN hotel.hotel h ON room.hotelno = h.hotelno
WHERE h.hotelname::text = 'Hilton'::text;

alter table ex1_4
    owner to postgres;

