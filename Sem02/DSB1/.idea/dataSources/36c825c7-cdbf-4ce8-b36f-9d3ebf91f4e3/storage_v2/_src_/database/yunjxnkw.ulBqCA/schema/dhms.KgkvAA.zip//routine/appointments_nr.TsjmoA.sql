create function appointments_nr() returns trigger
    language plpgsql
as
$$
DECLARE doc_ssn BIGINT;
begin
    if tg_op = 'INSERT' then
        doc_ssn = new.doctor_ssn;
    elsif tg_op = 'DELETE' then
        doc_ssn = old.doctor_ssn;
    end if;

    UPDATE doctor
    SET nr_appointments = (SELECT COUNT(doctor_ssn)
                           FROM appointed
                           WHERE doctor_ssn = doc_ssn AND time_from > CURRENT_DATE)
    WHERE ssn = doc_ssn;
    return new;
end;
$$;

alter function appointments_nr() owner to yunjxnkw;

